// ==UserScript==
// @name         Copiar título e número do vídeo (CADEMI)
// @namespace    Violentmonkey Scripts
// @version      1.1
// @description  Copia o número e o título do vídeo ativo
// @match        *://*.cademi.com.br/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Cria botão
    const botao = document.createElement('button');
    botao.innerText = '📋 Copiar Título';
    botao.style.position = 'fixed';
    botao.style.top = '10px';
    botao.style.right = '10px';
    botao.style.zIndex = '9999';
    botao.style.padding = '10px 15px';
    botao.style.background = '#28a745';
    botao.style.color = '#fff';
    botao.style.border = 'none';
    botao.style.borderRadius = '5px';
    botao.style.cursor = 'pointer';
    botao.style.fontSize = '14px';

    document.body.appendChild(botao);

    function removerAcentos(str) {
        return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }

    botao.addEventListener('click', () => {
        const activeItem = document.querySelector('.section-item.active');
        if (!activeItem) {
            alert("❌ Não encontrei vídeo ativo.");
            return;
        }

        const titleDiv = activeItem.querySelector('.item-titulo');
        let title = titleDiv?.innerText?.trim() || 'Sem título';

        // Remove acentos
        title = removerAcentos(title);

        // Obtém a lista da secção visível
        const parentSection = activeItem.closest('.section-items.collapse.show');
        const allVisibleItems = [...parentSection.querySelectorAll('.section-item')];

        // Encontra o índice do item ativo
        const index = allVisibleItems.findIndex(el => el.classList.contains('active'));

        // Procurar o nome do capítulo (elemento acima com class "section-group-titulo")
        const grupo = activeItem.closest('.section-group');
        let tituloGrupo = grupo ? grupo.querySelector('.section-group-titulo .item-titulo')?.innerText.trim() : 'Sem Capítulo';
        tituloGrupo = removerAcentos(tituloGrupo);

        const numero = String(index + 1).padStart(2, '0');
        const output = `VIDEO_NAME = "${tituloGrupo}/${numero} - ${title}"`;

        // Copia para a área de transferência e mostra alerta
        navigator.clipboard.writeText(output).then(() => {
            botao.innerText = '📋 Título copiado!';
            botao.style.background = '#333';
            setTimeout(() => {
                botao.innerText = '📋 Copiar Título';
                botao.style.background = '#28a745';
            }, 2000)
            // alert("✅ Copiado:\n" + output);
        });
    });
})();